/* 默认勾选 */
/* 默认勾选 */
/* 默认勾选 */

$(document).ready(function(){
	$('#field8730').attr("checked", true);
	$('#field8730').next().addClass("jNiceChecked");
});