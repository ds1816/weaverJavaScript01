/* 输入框增加提示文字 */
/* 输入框增加提示文字 */
/* 输入框增加提示文字 */

jQuery(document).ready(function(){
	$("#field6387").attr("placeholder", "请填写主送人");
});