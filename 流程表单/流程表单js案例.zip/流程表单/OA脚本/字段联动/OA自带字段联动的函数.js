datainput('field15974'); //电脑版

dataInput('field28561','5411|field28561,5411|field28570'); //手机版